import 'package:flutter/material.dart';

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[50],

      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text(
          "Tutor Flutter"
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Flexible(
            child: Container(
              height: MediaQuery.of(context).size.height,
              width: double.infinity,
              color: Colors.black38,
              child: const Center(
                child: Text(
                  "Holla World",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                  ),
                )
              ),
            ),
          ),
          Expanded(
            child: Container(
              height: MediaQuery.of(context).size.height,
              width: double.infinity,
              color: Colors.black38,
              child: const Center(
                child: Text(
                  "Holla World",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                  ),
                )
              ),
            ),
          )
        ],
      ),

    );
  }
}